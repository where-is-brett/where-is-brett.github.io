//
//  composed.h
//  AC Circuits
//
//  Created by Brett Yang on 01/05/2018.
//
//  Copyright © 2018 Brett Yang.
//  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//  The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
//
//  This class stores the properties
//
//

#ifndef composed_h
#define composed_h

#include <iostream>
#include <string>
#include "component.h"
#include "complex.h"

using namespace std;

class composed : virtual public component
{
private:
    string name, type="composed";
    double inductance, capacitance, resistance, frequency, magnitude_impedance, phase_difference;
    complex impedance;
public:
    // Default constructor
    composed() : inductance(0), capacitance(0), resistance(0), frequency(0), magnitude_impedance(0), phase_difference(0), name("") {}
    // Parameterised constructor
    composed(const double freq, const double phs_diff, const double res, const double cap, const double ind, complex imp) : inductance(ind), capacitance(cap), resistance(res), frequency(freq), phase_difference(phs_diff), impedance(imp)
    {
        // Use getMod() function from complex class definition to return the magnitude of impedance
        magnitude_impedance = imp.getMod();
    }
    // Destructor
    ~composed(){}
    
    
    // Function to set frequency and name
    void set_frequency(double freq) { frequency=freq; } // Despite the redundancy, this is needed for class to be non-abstract
    void set_name(string name_tag) { name=name_tag; }
    
    // Access functions
    double get_frequency() { return frequency; }
    complex get_impedance() { return impedance; }
    double get_magnitudeimpedance() { return magnitude_impedance; }
    double get_phasedifference() { return phase_difference; }
    string get_name() { return name; }
    string get_type() { return type; }
    double get_info() { return 0; }
    
};


#endif /* composed_h */
